﻿using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;
using System.Net.Http.Headers;

namespace Cctest
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            var configuration = builder.Build();

            // 1. Client client credentials client
            var app = ConfidentialClientApplicationBuilder
                .Create(configuration["AzureADServiceApi:ClientId"])
                .WithClientSecret(configuration["AzureADServiceApi:ClientSecret"])
                .WithAuthority(configuration["AzureADServiceApi:Authority"])
                .Build();

            var scopes = new[] { configuration["AzureADServiceApi:Scope"] };

            // 2. Get access token
            var authResult = await app.AcquireTokenForClient(scopes)
                .ExecuteAsync();


            if (authResult == null)
            {
                Console.WriteLine("no auth result... ");
            }
            else
            {
                Console.WriteLine(authResult.AccessToken);

                var tokenValue = "Bearer " + authResult.AccessToken;

                var client = new HttpClient();

                //client.BaseAddress = new Uri(_configuration["CallApi:ApiBaseAddress"]);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authResult.AccessToken);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // use access token and get payload
                var response = await client.GetAsync("https://dobi-crm-abstractionlayer-prod.azurewebsites.net/api/account?id=26e26897-05dd-ed11-8846-000d3a8315cf");
                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                }

                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }
    }
}